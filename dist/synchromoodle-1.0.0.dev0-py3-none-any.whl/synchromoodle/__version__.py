# coding: utf-8
"""
Version module
"""
# pragma: no cover
__version__ = '1.0.0.dev0'
